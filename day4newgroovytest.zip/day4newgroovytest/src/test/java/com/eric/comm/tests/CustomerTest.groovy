package com.eric.comm.tests

import static org.junit.jupiter.api.Assertions.*

import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.RepeatedTest

import com.eric.comm.dao.DBHelper
import com.eric.comm.models.Customer

import groovy.sql.Sql

import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.Arguments
import org.junit.jupiter.params.provider.CsvFileSource
import org.junit.jupiter.params.provider.MethodSource

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.stream.Stream
class CustomerTest {
	Sql conn;
	File propertyFile
	Properties properties
	Customer customerObj
	static def List<Customer> customerList= new ArrayList()
	static final Customer customer = new Customer()
	
	@BeforeAll
	static void getInitialized() {
		new CustomerTest().getAllCustomers()
		customer.setCustomerId(9834579)
		customer.setCustomerName("Parameswari")
		customer.setDob(LocalDate.of(1970, 12, 2))
	}

	@Test
	@DisplayName("Customer Instance Test")
	void whenFindCustomer_thenReturnData() {
	
		assertEquals("Parameswari", customer.getCustomerName())
		assertTrue((LocalDate.now()-customer.getDob()>50))
		
	}
	
	//db test
	@Test
	@DisplayName("Oracle Instance Test")
	@RepeatedTest(5)
	void WhenOracleDB_thenReturnInstance() {
	  //singleton test	
	  //assertTrue(new DBHelper().getConnection()!=null)
	  
	  assertTrue(new DBHelper().getConnection()!=null)
	}
	
	
	
	@ParameterizedTest	
	@CsvFileSource(resources = "./customer.csv", numLinesToSkip = 1)
	@DisplayName("Customer Instance Parameterized Test")
	void whenFindCustomer_thenReturnParameterizedData(int customerId,String customerName, String dob) {
	  		   	
		assertTrue(customerName.length()>3)
		assertTrue((LocalDate.now()-LocalDate.parse(dob)>50))
		
	}

	
	@ParameterizedTest
	@MethodSource("customerDataResource")
	@DisplayName("Customer Instance DB Parameterized Test")
	void whenFindCustomer_thenReturnDBParameterizedData(long customerId,String customerName, LocalDate dob) {
			
		println customerName
		println dob		 
		assertTrue(customerName.length()>3)
		//assertTrue((LocalDate.now()-dob>50))
		
	}
	
	
	def getAllCustomers() {
		properties=new Properties();
		propertyFile=new File(DBHelper.getPropertyFileName())
		conn=new DBHelper().getConnection()
		propertyFile.withInputStream { properties.load(it) }		
		conn.query(properties.customerSelectAll) { resultSet ->
			println resultSet.row.toString()
			while (resultSet.next()) {
			
				customerObj=new Customer();
				customer.setCustomerId(resultSet.getString(1).toString().toInteger())
				customer.setCustomerName(resultSet.getString(2))
				//customer.setDob(LocalDate.parse(resultSet.getString(3).toString()))				
				customerList.add(customer);				
			}
		  }
		  customerDataResource()		 
	}
	
	
	def static Stream<Arguments> customerDataResource(){
		//println customerList.size()
		Customer customer=customerList.get(0)
		return Stream.of(
			Arguments.of(customer.getCustomerId(),customer.getCustomerName(),customer.getDob())
			)
		
			
	}
	
}
